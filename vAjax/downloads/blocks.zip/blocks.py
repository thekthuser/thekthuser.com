#!usr/bin/env python
# -*- coding: utf-8 -*-

#file blocks.py

import os, sys, string



blocks = []

with open('cols200.txt', 'r') as infile:
    for line in infile:
        blocks.append(int(line.rstrip(os.linesep)))

blocks = tuple(blocks)
totalsum = sum(blocks)
numcols = 10
maxblockval = 10
avgcol = totalsum / numcols
avgcoldec = totalsum / (numcols * 1.0)
best = {'layout': None, 'balance':sys.maxint}



iter_cols = lambda x: range(len(x))


def create_cols(numcols):
    """Create a list with numcols columns."""
    cols = []
    for i in range(numcols):
        cols.append([])
    return cols


def verify_order(blocks, cols):
    """True if cols elements retain original order."""
    tcount = 0
    for i in iter_cols(cols):
        for j in range(len(cols[i])):
            if cols[i][j] == blocks[tcount]:
                tcount += 1
            else:
                return False
    if tcount != len(blocks):
        return False
    return True


def format_columns_horizontal(best):
    """Format columns suitable for output."""
    outstr = 'Balance Delta = ' + str(best['balance']) + os.linesep
    for i in iter_cols(best['layout']):
        outstr += str(best['layout'][i]) + ' sum: ' + str(sum(best['layout'][i])) + os.linesep
    return outstr


def format_columns_vertical(best):
    """Format columns suitable for output."""
    sums = map(sum, best['layout'])
    outlist = map(None,*best['layout'])
    outstr = ''
    count = 0
    for line in outlist:
        for char in line:
            if str(char) == 'None':
                char = 0
            if str(char) == '10':
                outstr += '   ' + str(char)
                count += 1
            if str(char) not in string.digits:
                del char
            else:
                outstr += '    ' + str(char)
                count += 1
            if count % numcols == 0:
                outstr += os.linesep
    outstr += os.linesep + "sum:" + str.strip(str(sums), '[]') + os.linesep
    outstr += 'Balance Delta = ' + str(best['balance']) + os.linesep
    return outstr


def balance_delta(cols):
    """Return the balance delta."""
    def sum_col(col):
        sum = 0
        for b in range(len(col)):
            sum += col[b]
        return sum
    def avg_length(cols):
        sum = 0
        for c in iter_cols(cols):
            sum += sum_col(cols[c])
        return (float(sum) / len(cols))

    bal = 0
    avg = avg_length(cols)
    for c in iter_cols(cols):
        bal += abs(sum_col(cols[c]) - avg)
    return bal


def merge(left, right):
    """Merge partially filled columns."""
    left += right[1:]
    return left


def guess_fill_one(blocks, numcols, avgcol, avgcoldec, tcol):
    """Given targetcol as int, return variations where abs(avgcoldec - colvalue) is minimized"""
    retcol = []
    ccolsum = (avgcol / 2) + (avgcol * tcol) #c: center
    ccoldex = 0                              #dex: index
    tsum = 0                                 #t:target
    while tsum < ccolsum:
        tsum += blocks[ccoldex]
        ccoldex += 1

    """increment, stop early"""
    loop = True
    downdex, updex = 1, 0
    downval, upval = blocks[ccoldex - downdex], blocks[ccoldex + updex]
    colval = upval + downval
    while loop:
        if upval > downval:
            downdex += 1
            downval = sum(blocks[ccoldex - downdex:ccoldex])
            colval = downval + upval
        elif downval >= upval:
             updex += 1
             upval = sum(blocks[ccoldex:ccoldex + updex])
             colval = downval + upval
        if (upval >= (avgcol / 2) - maxblockval) or (downval >= (avgcol / 2) - maxblockval):
            loop = False

    """count num till min abs(bal) for down and up"""
    pardowndex, parupdex = downdex, updex    #par: partial
    pardownval, parupval, parcolval = downval, upval, colval
    downdexleft, updexleft = 0,0             #left: remaining
    loop = True
    while loop:
        downdexleft += 1
        downdex += 1
        downval = sum(blocks[ccoldex - downdex:ccoldex])
        colval = downval + parupval
        if ccoldex - downdex == 0:
            loop = False
        if abs(avgcoldec - colval) < abs(avgcoldec - sum(blocks[ccoldex - (downdex + 1):ccoldex + parupdex])):
            loop = False
            retcol.append({'column':list(blocks[ccoldex - downdex:ccoldex + parupdex]), 'tcol':tcol, 'start':ccoldex - downdex, 'end':ccoldex + parupdex})
    loop = True
    while loop:
        updexleft += 1
        updex += 1
        upval = sum(blocks[ccoldex:ccoldex + updex])
        colval = pardownval + upval
        if ccoldex + updex == len(blocks):
            loop = False
            retcol.append({'column':list(blocks[ccoldex - pardowndex:ccoldex + updex]), 'tcol':tcol, 'start':ccoldex - pardowndex, 'end':ccoldex + updex})
        if abs(avgcoldec - colval) < abs(avgcoldec - sum(blocks[ccoldex - pardowndex:ccoldex + (updex + 1)])):
            loop = False
            retcol.append({'column':list(blocks[ccoldex - pardowndex:ccoldex + updex]), 'tcol':tcol, 'start':ccoldex - pardowndex, 'end':ccoldex + updex})

    """find best layout variations. return all valid results"""
    downdex, updex = pardowndex, parupdex
    downval, upval, colval = pardownval, parupval, parcolval
    for i in range(1, downdexleft + 1):
        if (ccoldex - downdex) > 0:
            downdex = pardowndex + i
            downval = sum(blocks[ccoldex - downdex:ccoldex])
        for j in range(1, updexleft + 1):
            if (ccoldex + updex) < len(blocks):
                updex = parupdex + j
                upval = sum(blocks[ccoldex:ccoldex + updex])
            colval = downval + upval
            if abs(avgcoldec - colval) < abs(avgcoldec - sum(blocks[ccoldex - downdex:ccoldex + (updex + 1)])):
                retcol.append({'column':list(blocks[ccoldex - downdex:ccoldex + updex]), 'tcol':tcol, 'start':ccoldex - downdex, 'end':ccoldex + updex})
                break
            if abs(avgcoldec - colval) < abs(avgcoldec - sum(blocks[ccoldex - (downdex + 1):ccoldex + updex])):
                retcol.append({'column':list(blocks[ccoldex - downdex:ccoldex + updex]), 'tcol':tcol, 'start':ccoldex - downdex, 'end':ccoldex + updex})

    if tcol == 0:
        for i in iter_cols(retcol):
            if retcol[i]['start'] != 0:
                retcol[i]['column'] = list(blocks[0:retcol[i]['end']])
                retcol[i]['start'] = 0
        dupes = retcol
        retcol = []
        for i in dupes:
            if i not in retcol:
                retcol.append(i)
    if tcol == numcols - 1:
        for i in iter_cols(retcol):
            if retcol[i]['end'] != len(blocks):
                retcol[i]['column'] = list(blocks[retcol[i]['start']:len(blocks)])
                retcol[i]['end'] = len(blocks)
        dupes = retcol
        retcol = []
        for i in dupes:
            if i not in retcol:
                retcol.append(i)
    return retcol


def fill_ltr(blocks, numcols, avgcoldec, scol, frm):
    """Given a column, fill all columns before or after it from left to right."""
    if frm == 'before':
        cols = create_cols(scol['tcol'] + 1)
        bindex = 0
        for c in range(scol['tcol']):
            if c == scol['tcol'] - 1:
                cols[c] = list(blocks[bindex:scol['start']])
            else:
                loop = True
                while loop:
                    cols[c].append(blocks[bindex])
                    bindex += 1
                    if abs(avgcoldec - sum(cols[c])) < abs(avgcoldec - (sum(cols[c]) + blocks[bindex])):
                        loop = False
        cols[-1] = scol['column']
    if frm == 'after':
        cols = create_cols(numcols - scol['tcol'])
        bindex = scol['end']
        cols[0] = scol['column']
        for c in range(1, len(cols)):
            if c == len(cols) - 1:
                cols[c] = list(blocks[bindex:len(blocks)])
            else:
                loop = True
                while loop:
                    cols[c].append(blocks[bindex])
                    bindex += 1
                    if abs(avgcoldec - sum(cols[c])) < abs(avgcoldec - (sum(cols[c]) + blocks[bindex])):
                        loop = False
    return cols


def fill_rtl(blocks, numcols, avgcoldec, scol, frm):
    """Given a column, fill all columns before or after it from right to left."""
    if frm == 'before':
        cols = create_cols(scol['tcol'] + 1)
        bindex = scol['start'] - 1
        cols[scol['tcol']] = scol['column']
        for c in reversed(range(len(cols) - 1)):
            if c == 0:
                cols[c] = list(blocks[0:bindex + 1])
            else:
                loop = True
                while loop:
                    cols[c][:0] = blocks[bindex],
                    bindex -= 1
                    if abs(avgcoldec - sum(cols[c])) < abs(avgcoldec - (sum(cols[c]) + blocks[bindex])):
                        loop = False
    if frm == 'after':
        cols = create_cols(numcols - scol['tcol'])
        bindex = len(blocks) - 1
        for c in reversed(range(1, len(cols))):
            if c == 1:
                cols[c] = list(blocks[scol['end']:bindex + 1])
            else:
                loop = True
                while loop:
                    cols[c][:0] = blocks[bindex],
                    bindex -= 1
                    if abs(avgcoldec - sum(cols[c])) < abs(avgcoldec - (sum(cols[c]) + blocks[bindex])):
                        loop = False
        cols[0] = scol['column']
    return cols



for tcol in range(numcols):
    cols = guess_fill_one(blocks, numcols, avgcol, avgcoldec, tcol)
    for scol in cols:
        ll = merge(fill_ltr(blocks, numcols, avgcoldec, scol, 'before'), fill_ltr(blocks, numcols, avgcoldec, scol, 'after'))
        lr = merge(fill_ltr(blocks, numcols, avgcoldec, scol, 'before'), fill_rtl(blocks, numcols, avgcoldec, scol, 'after'))
        rl = merge(fill_rtl(blocks, numcols, avgcoldec, scol, 'before'), fill_ltr(blocks, numcols, avgcoldec, scol, 'after'))
        rr = merge(fill_rtl(blocks, numcols, avgcoldec, scol, 'before'), fill_rtl(blocks, numcols, avgcoldec, scol, 'after'))
        if balance_delta(ll) < best['balance']:
            best['layout'] = ll
            best['balance'] = balance_delta(ll)
        if balance_delta(lr) < best['balance']:
            best['layout'] = lr
            best['balance'] = balance_delta(lr)
        if balance_delta(rl) < best['balance']:
            best['layout'] = rl
            best['balance'] = balance_delta(rl)
        if balance_delta(rr) < best['balance']:
            best['layout'] = rr
            best['balance'] = balance_delta(rr)
if verify_order(blocks, best['layout']):
    print format_columns_horizontal(best)
#    print format_columns_vertical(best)
