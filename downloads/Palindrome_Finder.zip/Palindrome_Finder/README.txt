README for palindrome.py

Requires python(2.7.6), cherrypy

To run:
  cd to directory
  python palindrome.py
  open browser to 127.0.0.1:8080

Note: You provided the sample text in a pdf. To extract it I had to open in LibreOffice Draw (Writer defaulted to that) and manually copy/paste the lines. If it returns the wrong string for the default text it's possible I copied the sample text wrong.

  
Note: If running several of these cherrypy applications consecutively, remember to clear variables in the url in between.