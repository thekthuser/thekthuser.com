#!usr/bin/env python
# -*- coding: utf-8 -*-

#file palindrome.py

import cherrypy

class Palindrome(object):
    @cherrypy.expose
    def index(self, user_input=""):
        out = ""

        default = "FourscoreandsevenyearsagoourfaathersbroughtforthonthiscontainentanewnationconceivedinzLibertyanddedicatedtothepropositionthatallmenarecreatedequalNowweareengagedinagreahtcivilwartestingwhetherthatnaptionoranynartionsoconceivedandsodedicatedcanlongendureWeareqmetonagreatbattlefiemldoftzhatwarWehavecometodedicpateaportionofthatfieldasafinalrestingplaceforthosewhoheregavetheirlivesthatthatnationmightliveItisaltogetherfangandproperthatweshoulddothisButinalargersensewecannotdedicatewecannotconsecratewecannothallowthisgroundThebravelmenlivinganddeadwhostruggledherehaveconsecrateditfaraboveourpoorponwertoaddordetractTgheworldadswfilllittlenotlenorlongrememberwhatwesayherebutitcanneverforgetwhattheydidhereItisforusthelivingrathertobededicatedheretotheulnfinishedworkwhichtheywhofoughtherehavethusfarsonoblyadvancedItisratherforustobeherededicatedtothegreattdafskremainingbeforeusthatfromthesehonoreddeadwetakeincreaseddevotiontothatcauseforwhichtheygavethelastpfullmeasureofdevotionthatweherehighlyresolvethatthesedeadshallnothavediedinvainthatthisnationunsderGodshallhaveanewbirthoffreedomandthatgovernmentofthepeoplebythepeopleforthepeopleshallnotperishfromtheearth"

        if not user_input:
            user_input = default
        user_input = user_input.replace(' ', '')
        
        #i for in, o for out
        ipals = find_all_pals(user_input)
        opals = []
        for pal in ipals:
            pal = expand_pal(user_input, pal)
            opals.append(pal)
        out += max(opals, key=len)


        return """
            <html>
                <head><title>Palindrome Finder</title></head>
                <body>
                    <h1>Palindrome Finder</h1>
                    <p>Enter a block of text (without spaces) to find the longest substring that is the same in reverse (a palindrome).</p>
                    <table>
                        <tr>
                            <td>
                            <p>The default text is:<br />
                            Fourscoreandsevenyearsagoourfaathersbroughtforthonthiscontainentanewnationconceiv<br />edinzLibertyanddedicatedtothepropositionthatallmenarecreatedequalNowweareengagedi<br />nagreahtcivilwartestingwhetherthatnaptionoranynartionsoconceivedandsodedicatedcanlo<br />ngendureWeareqmetonagreatbattlefiemldoftzhatwarWehavecometodedicpateaportionoft<br />hatfieldasafinalrestingplaceforthosewhoheregavetheirlivesthatthatnationmightliveItisalto<br />getherfangandproperthatweshoulddothisButinalargersensewecannotdedicatewecannotco<br />nsecratewecannothallowthisgroundThebravelmenlivinganddeadwhostruggledherehaveco<br />nsecrateditfaraboveourpoorponwertoaddordetractTgheworldadswfilllittlenotlenorlongre<br />memberwhatwesayherebutitcanneverforgetwhattheydidhereItisforusthelivingrathertobed<br />edicatedheretotheulnfinishedworkwhichtheywhofoughtherehavethusfarsonoblyadvancedI<br />tisratherforustobeherededicatedtothegreattdafskremainingbeforeusthatfromthesehonore<br />ddeadwetakeincreaseddevoti>ontothatcauseforwhichtheygavethelastpfullmeasureofdevoti<br />onthatweherehighlyresolvethatthesedeadshallnothavediedinvainthatthisnationunsderGod<br />shallhaveanewbirthoffreedomandthatgovernmentofthepeoplebythepeopleforthepeoplesh<br />allnotperishfromtheearth
                            </p>
                            </td>
                            <td>
                            <form method="get" action="index">
                                <textarea rows="20" cols="100" type="text" value="" name="user_input"></textarea>
                                <button type="submit">Submit</button>
                            </form>
                            </td>
                        <tr>
                    <td>
                        <br /><p>The longest palindrome is <b>""" + out + """</b>
                    </td>
                    </tr>
                </body>
            </html>"""

#True is palindrome, otherwise False
def is_pal(pal):
    if len(pal) % 2 == 0:
        left = pal[:len(pal) / 2]
        right = pal[len(pal) / 2:]
    else:
        left = pal[:len(pal) / 2]
        right = pal[(len(pal) / 2) + 1:]

    if left == right[::-1]:
        return True
    else:
        return False

#returns all 2 and 3 character palindromes
def find_all_pals(text):
    #first part of internal array is pal index, second is pal itself
    pals = []

    #two character palindromes
    for i in range(len(text) - 1):
        if text[i] == text[i + 1]:
            pals.append([i, text[i:i + 2]])

    #three character palindromes
    for i in (range(1, len(text) - 1)):
        last = text[i - 1]
        curr = text[i]
        nxt = text[i + 1]
        if last == nxt:
            pals.append([i, text[i - 1: i + 2]])

    return pals

#lengthen pal as much as possible
def expand_pal(text, ipal):
    index = ipal[0]
    length = len(ipal[1])

    #even character palindromes
    if length % 2 == 0:
        left = index
        right = index + 2
        while True:
            if (left - 1 < 0) or (right + 1 > len(text) - 1):
                return text[left:right]
            if is_pal(text[left - 1: right + 1]):
                left -= 1
                right += 1
            else:
                return text[left:right]
                
    #odd character palindromes
    else:
        left = index - 1
        right = index + 2
        while True:
            if (left - 1 < 0) or (right + 1 > len(text) - 1):
                return text[left:right]
            if is_pal(text[left - 1: right + 1]):
                left -= 1
                right += 1
            else:
                return text[left:right]


if __name__ == '__main__':
    cherrypy.quickstart(Palindrome());
