=================================================================================================

Diablo for the TI-83 and 83+

Version 1.0

=================================================================================================

A few quick hints and tips:

- Strength and Magic are only needed to meet the requirements to use weapons or spells.  Unless
	you find yourself running out of mana, do not raise these stats over the weapon or
	spell's required level.
- Your % chance to hit a monster is (Dexterity + 50 - Monster's armor class)
	(Armor class is represented by the variable A).  You do not need to invest heavily into
	Dexterity, a few points every few levels should be fine.
- Everything is based on your level.  Your damage, monster's HP, damage, AC, and the monsters
	that you meet are dependant on your character level.
- There are 6 quests.  The Butcher, King Leoric, The Dark Passage, The Warlord of Blood,
	Archbishop Lazarus, and Diablo.  You will only see each of these once, but they will all
	be reset after you see Diablo.
- At higher levels, it may be best to run from weaker monsters.  They aren't worth the experience
	and can damage you, thus lowering your chances of killing higher exp monsters.
- Warriors are encouraged to put the first 2 levels directly into strength, this allows them to
	upgrade to the short bow right away.
- Rogues are probably the hardest class to play, as a result of their lower HP.  To compensate
	for this, they have reduced requirements for both bows and firewall.
- You only have one healing potion and one mana potion per level.  They do not carry over.  If
	you find yourself in need of life or mana, there are shrines that you may encounter, just
	keep running until you find one.

=================================================================================================

Misc.

- Please don't be an @$$ and change the my name to yours in the code or below.

- In order to save a game, you must first 
	hit 2nd (the yellow button)
	hit MATRX (located on	the X-1 button, 2 under the green button).
	hit the left arrow key
	hit 9
	type 27
	hit 2nd, quit (over mode, to the left of 2nd)

- Any suggestions, questions, or bugs?  Email me @ calvin_o_saurus@hotmail.com

- Developed by Chris Peters :)
=================================================================================================