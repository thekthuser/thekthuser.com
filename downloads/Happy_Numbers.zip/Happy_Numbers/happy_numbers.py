#!usr/bin/env python
# -*- coding: utf-8 -*-

#file happy_numbers.py

import cherrypy

class HappyNumbers(object):

    @cherrypy.expose
    def index(self, user_input=""):
        out = ""
        if (user_input):
            out += "["
            numbers = user_input.replace(' ', '').split(',')
            for i in numbers:
                try:
                    int(i)
                except ValueError:
                    out += "Not a number,  "
                else:
                    if int(i) <= 0:
                        out += "Not a positive number,  "
                    else:
                        if is_happy(i):
                            out += i + ", "
            out = out[:-2]
            out += "]"

        return """
        <html>
            <head><title>Happy Numbers</title></head>
            <body>
                <h1>Happy Numbers</h1>
                <p>A happy number is defined by the following process. Starting with any positive integer, replace the number by the sum of the squares of its digits, and repeat the process until the number equals 1 (where it will stay), or loops endlessly in a cycle which does not include 1. Those numbers for which this process ends in 1 are happy numbers, while those that do not end in 1 are unhappy numbers (or sad numbers).<p>
                <p>When mulitple numbers are input, they should be seperated by commas.</p>
                <table>
                    <tr>
                        <form method="get" action="index">
                            <input type="text", value="" name="user_input" />
                            <button type="submit">Submit</button>
                        </form><br />
                    </tr>
                    <tr> """ + out + """</tr>
                </table>
            </body>
        </html>"""


def is_happy(number):
    #split to characters (later change to digits)
    number = list(number)
    past = [number]

    while True:
        num = 0
        #find sum
        for i in number:
            num += int(i) ** 2

        #ends with 1, is happy
        if num == 1:
            return True
        #loops endlessly, unhappy
        if num in past:
            return False

        #record past (if happiness is not yet determined
        past.append(num)
        #restart with new number
        number = str(num)


if __name__ == '__main__':
    cherrypy.quickstart(HappyNumbers());
