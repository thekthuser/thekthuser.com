README for alien_numbers.py

Requires python(2.7.6), cherrypy

To run:
  cd to directory
  python alien_numbers.py
  open browser to 127.0.0.1:8080

  
Note: If running several of these cherrypy applications consecutively, remember to clear variables in the url in between.