#!usr/bin/env python
# -*- coding: utf-8 -*-

#file alien_numbers.py

import cherrypy

class Alien_Numbers(object):
    @cherrypy.expose
    def index(self, user_input=""):
        out = ""
        if user_input:
            number, source, target = user_input.split(' ')
            out += "Translated: " + convert(to_decimal(number, source), target)

        return """
            <html>
                <head><title>Alien Numbers</title></head>
                <body>
                    <h1>Alien Numbers</h1>
                    <p>The decimal system is composed of ten digits, which we represent as '0123456789' (the digits in a system are written from lowest to highest). Imagine you have discovered an alien numeral system composed of some number of digits, which may or may not be the same as those used in decimal. For example, if the alien numeral system were represented as 'oF8', the numbers one through ten would be:<br /><br /> F,8,Fo, FF, F8, 8o, 8F, 88, Foo, FoF<br /><br />We would like to be able to work with numbers in arbitrary alien systems. More generally, we want to be able to convert an arbitrary number that's written in one alien system into a second system.</p>
                    <p>Input: alien_number source_language target_language (Note that inputs are seperated by spaces.)<br /><br />Each language will be represented by a list of its digits, ordered from lowest to highest value. No digit will be repeated in any representation, all digits in the alien number will be present in the source language, and the first digit of the alien number will not be the lowest valued digit of the source language (in other words, the alien numbers have no leading zeros). Each digit will either be a number 0-9, an uppercase or lowercase letter, or one of the following symbols !"#$%&'()*+,-./:;?@[\]^_`{|}~</p>
                    <h2>Translate a number:</h2>
                    <table><tr>
                            <form method="get" action="index">
                                <input type="text" value="" name="user_input" style="width:50%;" />
                                <button type="submit">Submit</button>
                            </form>
                        </tr>
                        <tr>
                            <td>
                            """ + out + """
                            </td>
                    </tr></table>
                </body>
            </html>"""


#returns a dict of language digits translated to decimal
def digit_value(language, to_decimal):
    digits = {}

    for i in range(len(language)):
        #keys and values need to be reversed when converting to and from decimal
        if to_decimal == True:
            digits[language[i]] = i
        else:
            digits[i] = language[i]
    return digits

#converts into decimal representation
def to_decimal(number, source):
    base = len(source)
    digits = digit_value(source, True)
    in_ten = 0

    #i is digit's index position, j is column value (power to raise to)
    i, j = 0, len(number) - 1
    while i < len(number):
        in_ten += digits[number[i]] * (base ** j)
        i += 1
        j -= 1
    return in_ten

#converts from decimal to target alien
def convert(number, target):
    base = len(target)
    in_target = ""
    digits = digit_value(target, False)

    #divide number by base. remainder is column's digit, result is divided again
    for i in range(len(str(number))):
        in_target += str(digits[number % base])
        number = number / base
    #in_target is backwards
    return in_target[::-1]


if __name__ == '__main__':
    cherrypy.quickstart(Alien_Numbers());
